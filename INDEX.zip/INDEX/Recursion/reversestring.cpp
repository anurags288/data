#include <iostream>
using namespace std;
string reversed="";
void reverse(string n,int len)
{
	if (len!=-1)
	{
		//char c=n.at(len);
		reversed=reversed+n.at(len);
		//len--;
		reverse(n,(len-1));
	}
	else
	return;
	
}
int main()
{
	string s;
	int l=0;
	//char c;
	cout <<"\nenter string \n";
	getline(cin,s);
	l=s.length();
	l=l-1;
	reverse(s,l);
	cout << "Reversed String is: " << reversed << endl;
	return 0;
}
