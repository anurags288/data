#include<iostream>
using namespace std;

int gcd(int a,int b)
{
	if(a<b)
	{
		int temp=a;
		a=b;
		b=temp;
	}
	
	int rem=1,divd=a,div=b;
	while(rem!=0)
	{
		rem=a%b;
		a=b;
		b=rem;
	}
	
	return a;

}


int gcdr(int a,int b)
{
	if(a<b)
	{
		int temp=a;
		a=b;
		b=temp;
	}

	if(b==0)
          return a;
	
	return gcdr(b,a%b);
	
}

int main()
{
	int ch;
	do{
		cout<<"\n\n\t\tGCD";
		cout<<"\n1.Using iteration";
		cout<<"\n2.Using recurssion";
		cout<<"\n3.Exit";
		cout<<"\nEnter your choice:";
		cin>>ch;
		switch(ch)
		{
			case 1:
				int a,b;
				cout<<"\nEnter two numbers:";
				cin>>a>>b;
				if(a<=0 || b<=0)
	 			cout<<"\nGCD cannot be computed";
				else
				cout<<"\nGCD is:"<<gcd(a,b);
				break;
			case 2:
				cout<<"\nEnter two numbers:";
				cin>>a>>b;
				if(a<=0 || b<=0)
	 			cout<<"\nGCD cannot be computed";
				else
				   cout<<"\nGCD is:"<<gcdr(a,b);
				break;
			case 3:break;
		} 
	}while(ch!=3);
	return 0;
}
