#include <iostream>
using namespace std;
class q
{
	private:
		int a,b;
	public:
		int power(int b,int r);
		void display();
};
int q::power(int b,int r)
{
	if (r==0)
	{
		return 1;
	}
	else
	{
		return (b*power(b,(r-1)));
	}
}
void q::display()
{
	cout <<"Enter Base::";
	cin >>a;
	cout <<endl;
	cout <<"Enter Power to Base::";
	cin >>b;
	cout << endl;
	q p;
	int answer=p.power(a,b);
	cout << answer << endl;
}
int main()
{
	q p1;
	p1.display();
	return 0;
}
