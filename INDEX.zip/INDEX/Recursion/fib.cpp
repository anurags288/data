#include<iostream>
using namespace std;

void fib(int n)
{
	int a=0,b=1;
	cout<<a<<" "<<b<<" ";
	for(int i=0;i<n;i++)
	{
		int s=a+b;
		a=b;
		b=s;
		cout<<b<<" ";
	}
}

int fibr(int n)
{
	if(n==1 || n==0)
	   return n;
	else
	   return fibr(n-1)+fibr(n-2);
}

int main()
{
	int ch;
	do{
		cout<<"\n\n\t\tFIBONACCI SERIES";
		cout<<"\n1.Using iteration";
		cout<<"\n2.Using recurssion";
		cout<<"\n3.Exit";
		cout<<"\nEnter your choice:";
		cin>>ch;
		switch(ch)
		{
			case 1:
				int no;
				cout<<"\nEnter the size:";
				cin>>no;
				if(no<0)
	 			cout<<"\nSeries does not exist";
				else
				fib(no);
				break;
			case 2:
				cout<<"\nEnter the size:";
				cin>>no;
				if(no<0)
	 			cout<<"\nSeries does not exist";
				else
				   for(int i=0;i<no+2;i++)
					cout<<fibr(i)<<" ";
				break;
			case 3:break;
		} 
	}while(ch!=3);
	return 0;
}
