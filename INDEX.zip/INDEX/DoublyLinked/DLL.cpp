#include<iostream>
using namespace std;

template <class T>
class node
{
   public:
	T data;
	node* next;
	node* prev;
	node()
	{
		next=prev=NULL;
	}

};

template <class T>
class DLL
{
	node<T>* head, *tail;

  public:
	DLL()
	{
		head=tail=NULL;
	}
	void addAtBeg(T num);
	void addAtEnd(T num);
	void delFromBeg();
	void delFromEnd();
	void reverse();
	void display();
	//void concat(DLL);
	bool delNode(T num);
	bool search(T num);
	//void insert(int pos,T num);
	void menu(int ch);
};
template <class T>
void DLL<T>::addAtBeg(T num)
{
	node<T>* temp=new node<T>();
	temp->data=num;
	if (head==NULL)
	{
		head=tail=temp;
	}
	else
	{
		temp->next=head;
		head->prev=temp;
		head=temp;
	}
	display();
}
template <class T>
void DLL<T>::addAtEnd(T num)
{
	node<T>* temp=new node<T>();
	temp->data=num;
	if (tail==NULL)
	{
		head=tail=temp;
	}
	else
	{
		tail->next=temp;
		temp->prev=tail;
		tail=temp;
		tail->next=NULL;
	}
	display();
}
template <class T>
void DLL<T>::delFromBeg()
{
	node<T>* temp;
	T el;
	if (head==NULL)
	{
		cout<<"Empty List"<< endl;
	}
	else
	{
		temp=head;
		head->prev=NULL;
		head=head->next;
		cout <<"Deleted Node Data: " << temp->data << endl;
		delete temp;
	}
	display();
}
template <class T>
void DLL<T>::delFromEnd() 
{
	node<T>* temp;
	T el;
	if (tail==NULL)
	{
		cout<<"Empty List"<< endl;
	}
	else
	{
		temp=tail;
		tail->prev->next=NULL;//jo actual tail ke phele wala hai wo ab null ko pint karega
		tail=tail->prev;
		cout <<"Deleted Node Data: " << temp->data << endl;
		delete temp;
	}
	display();
}
template <class T>
bool DLL<T>::delNode(T num)
{
	
	if (head!=NULL)
	{
		if (head==tail && head->data == num)
		{
			delete head;
			head=tail=NULL;
			return true;
		}
		else if (head->data==num)
		{
			node<T>* temp;
			temp=head;
			head=head->next;
			head->prev=NULL;
			delete temp;
			return true;
		}
		else
		{
			node<T>* temp;
			for (temp=head; temp!=NULL && !(temp->data==num); temp=temp->next);
			if (temp!=NULL)
			{
				temp->prev->next=temp->next;//2 3 4 : to delete 3 now 2 which is 3 ka prev 
				if (temp==tail)// 2 3: 3 to delete
				{
					tail=temp->prev;
					temp->prev->next=NULL;
				}
				delete temp;
				return true;
			}
		}
	}
	return false;
}
template <class T>
bool DLL<T>::search(T num)
{
	node<T> *temp;
	for (temp=head;temp!=NULL;temp=temp->next)
	{
		if (temp->data==num)
		{
			cout <<"Found: "<<endl;
			return true;
		}
	}
	return false;
}
template <class T>
void DLL<T>::display()
{
	cout <<"List is: ";
	for (node<T>*temp=head;temp!=NULL;temp=temp->next)
	{
		cout << temp->data <<" ";
	}
	cout << endl;
}
template <class T>
void DLL<T>::reverse()
{
	if (head==NULL)
	{
		cout <<"Empty List"<<endl;
		return;
	}
	cout<<"-------------------Before Reversing------------------------------------"<< endl;
	display();
	cout<<"-------------------After Reversing------------------------------------"<< endl;
	node<T>* p1,*p2,*p3;
	p1=head;
	p2=head->next;
	p1->next=NULL;
	while(p2!=NULL)
	{
		p3=p2->next;
		p2->next=p1;
		p1=p2;
		p2=p3;
	}
	head=p1;
	display();
}
template<class T>
void DLL<T>::menu(int ch)
{
	char ch1;	
	T num;
	DLL<T> t;
	switch(ch)
	{
		case 1:
			cout<<"\nEnter the data:";
			cin>>num;
			addAtBeg(num);
			break;
		case 2:
			cout<<"\nEnter the data:";
			cin>>num;
			addAtEnd(num);
			break;
		case 3:
			delFromBeg();
			break;
		case 4:
			delFromEnd();
			break;
		case 5:
			cout<<"\nEnter the data to be deleted:";
			cin>>num;
			if(delNode(num))
			   cout<<"\nNode deleted";
			else
			   cout<<"\nNode not found";
			break;
		case 6:
			cout<<"\nEnter the data to be searched for:";
			cin>>num;
			if(search(num))
			   cout<<"\nNode present";
			else
			   cout<<"\nNode not found";
			break;
			
		case 7:
			display();
			break;
		case 8:
			reverse();
			break;
		/*case 9:
			concat(t);
			break;
		case 10:
			int pos;
			cout<<"\nEnter the data:";
			cin>>num;
			cout<<"\nEnter the position:";
			cin>>pos;
			insert(pos,num);
			break;*/
		case 11:
			return;
			
			
	}
}



//=======================================================
int main()
{
	int ch,ch1;
	do{
		DLL<int> si;
		DLL<float> sf;
		DLL<char> sc;
		cout<<"\n\n\t\tChoose a data type";
		cout<<"\n\n1.Integer";
		cout<<"\n2.Float";
		cout<<"\n3.Character";
		cout<<"\n4.Exit";
		cout<<"\nEnter your choice:";
		cin>>ch1;
		if(ch1!=4)
	        do{
		      cout<<"\n\n\t\tDOUBLY LINKED LIST";
		      cout<<"\n1.Add at begining";
		      cout<<"\n2.Add at end";
		      cout<<"\n3.Delete from begining";
		      cout<<"\n4.Delete from end";
		      cout<<"\n5.Delete a node";
		      cout<<"\n6.Search ";
		      cout<<"\n7.Display list";
		      cout<<"\n8.Reversing the list";
		      //cout<<"\n9.Conactenate two lists";
		      //cout<<"\n10.Insert at a location";
		      cout<<"\n11.Return";
		      cout<<"\nEnter your choice:";
		      cin>>ch;
		      switch(ch1)
		      {
			 case 1:
				si.menu(ch);
				break;
			 case 2:
				sf.menu(ch);
				break;
			 case 3:
				sc.menu(ch);
				break;
			 case 4:
				break;
		      }
		}while(ch!=11);
	}while(ch1!=4);
}

