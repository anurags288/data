#include <iostream>
using namespace std;
template <class t>
class node
{
	public:
		t data;
		node *next;
		node()
		{
			next=NULL;
		}
};
template <class t>
class QLL
{
	private:
	node <t> *head,*tail;
	public:
		QLL()
		{
			head=NULL;
			tail=NULL;
		}
		void enqueue(t a);
		void dequeue();
		void display();
		void menu(int c);
};
template <class t>
void QLL<t>::enqueue(t a)
{
	node<t> *temp=new node<t>();
	temp->data=a;
	if (tail==NULL)
	{
		head=tail=temp;
		tail->next=tail;
	}
	else
	{
		tail->next=temp;
		tail=temp;
		tail->next=NULL;//circular queue
	}
	cout <<"Added Successfully"<<endl;
}
/*template <class t>
void QLL<t>::dequeue()
{
	if (head=NULL)
	{
		cout <<"Empty Queue"<< endl;
		
	}
	else
	if (head==tail)
	{
		cout <<"Dequeue Successfully: "<< head->data << endl;
		delete head;
		head=tail=NULL;
	}
	else
	{
		node <t> *temp;
		temp=head;
		tail->next=head->next;
		head=head->next;
		cout <<"Dequeue Successfully: "<< temp->data << endl;
		delete temp;
	}
}*/

//===================================================================
template <class t>
void QLL<t>::dequeue()
{
	if(head==NULL)
		cout<<"\nQueue is empty";
	else
	if(head==tail)
	{
		cout<<"\nDeleted information:"<<head->data;
		delete head;
		head=tail=NULL;
	}
	else
	{
		node<t>* temp=head;
		tail->next=head->next;
		head=head->next;
		cout<<"\nDeleted information:"<<temp->data;
		delete temp;
	}
}
//==================================
template <class t>
void QLL<t>::display()
{
	cout <<"Present Queue is: ";
	node<t>* temp;
	for (temp=head;temp!=NULL;temp=temp->next)
	{
		cout << temp->data <<" ";
	}
	cout <<endl;
}
template <class t>
void QLL<t>::menu(int c)
{
	t num;
	if (c==1)
	{
		cout <<"\nNumber: ";
		cin>>num;
		cout << endl;
		enqueue(num);
	}
	else if(c==2)
	{
		dequeue();
	}
	else if (c==3)
	{
		cout<<endl;
		display();
		cout<< endl;
	}	
}

int main()
{
	QLL <int> i;
	QLL <double> d;
	QLL <float> f;
	int c1,c2;
	do{
		cout <<"\n1.Integer";
		cout <<"\n2.Double";
		cout <<"\n3.Float";
		cout <<"\n4.Exit";
		cout <<"\nEnter Choice: ";
		cin>>c1;
		if (c1!=4)
		{
			do{
			
			cout <<"\n1.Enqueue";
		    cout <<"\n2.Dequeue";
		    cout <<"\n3.Display";
		    cout <<"\n4.Exit";
		    cout <<"\nEnter Choice: ";
		    cin>>c2;
		    if (c2!=4)
		    {
			switch(c1)
			{
				case 1:
					i.menu(c2);
					break;
				case 2:
					d.menu(c2);
					break;
				case 3:
					f.menu(c2);
					break;
			}
		    }
		}while(c2!=4);
		}
	}while(c1!=4);
	return 0;
}






