#include<iostream>
using namespace std;
template<class T>
class stack
{ public:
	T data;
	stack<T> *prev;
};
template<class T>
class s
{
	stack<T> *top;
	public:
		s()
		{
			top=NULL;
		}
		void push(T n)
		{
			stack<T> *temp;
			temp=new stack<T>;
			temp->data=n;
			temp->prev=top;
			top=temp;
		}
		T pop()
		{
			T a;
			if(top==NULL)
			{
				cout<<"stack underflow"<<endl;
			}
			else
			{
				a=top->data;
				top=top->prev;
				return a;
			}
		}
		void display()
		{
			stack<T> *temp;
			temp=top;
			while(temp->prev!=NULL)
			{   cout<<temp->data<<" ";
				temp=temp->prev;
			}
			cout<<temp->data<<endl;
		}
		
};

int main()
{
	s<int> s1;
	int t1,t2,l;
	char ch;
	string st1;
	do
	{
		cout<<"enter expression in postfix form"<<endl;
		cin>>st1;
		l=st1.length();
		for(int i=0;i<l;i++)
		{
			switch(st1[i])
			{
				case '+': t1=s1.pop();
				           t2=s1.pop();
				           s1.push(t1+t2);
				           break;
			    case '-': t1=s1.pop();
				           t2=s1.pop();
				           s1.push(t1-t2);
				           break;
				           
				case '*': t1=s1.pop();
				           t2=s1.pop();
				           s1.push(t1*t2);
				           break;
				           
	           case '/': t1=s1.pop();
				           t2=s1.pop();
				           s1.push(t1/t2);
				           break;
				           
	          case '%': t1=s1.pop();
				           t2=s1.pop();
				           s1.push(t1%t2);
				           break;
			 default: s1.push(st1[i]-'0');
				       }
				   }
				   cout<<"Resulting expression"<<endl;
				   s1.display();
				   cout<<"do you want to continue"<<endl;
				   cin>>ch;
			}while(ch=='y');
		return 0;}
	
