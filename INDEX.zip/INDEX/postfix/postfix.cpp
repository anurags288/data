
#include <iostream>
#include <stdlib.h>
#include <math.h>
#include <ctype.h>
#include<conio.h>
#include<string.h>
using namespace std;
const int MAX = 50 ;
class postfix
{
	private :

		int stack[MAX] ;
		int top, nn ;
		char s[MAX] ;
	public :
		postfix( ) ;
		void setexpr ( char *str ) ;
		void push ( int item ) ;
		int pop( );
		void calculate( ) ;
		void show( ) ;
} ;
postfix :: postfix( )
{
	top = -1 ;
}
void postfix :: setexpr ( char str[] )
{
	strcpy(s,str);
        cout<<s;
}
void postfix :: push ( int item )
{
	if ( top == (MAX - 1 ))
		cout<<"Stack is full" ;
	else
	{
		top++ ;
		stack[top] = item ;
	}
}
int postfix :: pop( )
{
	if ( top == -1 )
	{
		cout << endl << "Stack is empty" ;
		return -1 ;
	}
	int data = stack[top] ;
	top-- ;
	return data ;
}
void postfix :: calculate( )
{
	int n1, n2, n3 ,i=0;
	while ( s[i]!='\0')
	{
		if ( s[i] == ' ' || s[i] == '\t' )
		{
		    ++i;
			continue;
		}
		if ( isdigit ((char)s[i] ) )
		{
			nn = (int)s[i];
			push ( nn ) ;
		}
		else
		{
			n1 = pop( ) ;
			n2 = pop( ) ;
			switch ((char)s[i] )
			{
				case '+' :
					n3 = n2 + n1 ;
					break ;
				case '-' :
					n3 = n2 - n1 ;
					break ;
				case '/' :
					n3 = n2 / n1 ;
					break ;
				case '*' :
					n3 = n2 * n1 ;
					break ;
				case '%' :
					n3 = n2 % n1 ;
					break ;
				case '$' :
					n3 = pow ( n2 , n1 ) ;
					break ;
				default :
					cout << "Unknown operator" ;
					exit ( 1 ) ;
			}

			push ( n3 ) ;
		}
		++i;
	}
}
void postfix :: show( )
{
	nn = pop ( ) ;
	cout << "Result is: " << nn ;
}

 int main()
{
	char expr[MAX] ;
	cout << "\nEnter postfix expression to be evaluated : " ;
	cin.getline(expr,MAX) ;
	cout<<expr;
	postfix q ;
	q.setexpr ( expr ) ;
	q.calculate( ) ;
	q.show( ) ;
	getch();
}
