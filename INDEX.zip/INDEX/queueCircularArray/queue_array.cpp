#include <iostream>
using namespace std;
template <class t,int size=10>
class queue
{
	public:
		int first,last;
		t storage[size];
		queue()
		{
			first=last=-1;
		}
		void enqueue(t a);
		t dequeue();
		bool isFull()
		{
			if(first==0 && last==size-1 || first==last+1)
			return true;
			else
			return false;
		}
		bool isEmpty()
		{
			if (first==-1)
			return true;
			else
			return false;
		}
		bool menu(t c);
		
};
template <class t,int size>
void queue<t,size>::enqueue(t a)
{
	if (!isFull())
	{
		if (last==size-1 || last==-1){
		storage[0]=a;
		last=0;
		if (first==-1)
		first=0;}
		else
		storage[++last]=a;
	}
	else
	cout <<"Full" << endl;
}
template <class t,int size>
t queue<t,size>::dequeue()
{
	if (first!=-1){
	t b;
	b=storage[first];
	if (first==size-1)
	first=0;
	else if (first==last)
	first=last=-1;
	else
	first++;
	return b;
 } 
 else
 return -1;
}
template <class t,int size>
bool queue<t,size>::menu(t c)
{
	bool f=true;
	t num;
	if (c==1)
	{
		cout <<"Enter number: "<< endl;
		cin >> num;
		enqueue(num);
		f=false;
		return f;
	}
	else if (c==2)
	{
		num=dequeue();
		if (num!=-1)
		cout <<"Done: "<< num << endl;
		else
		cout <<"Empty Queue"<< endl;
		f=false;
		return f;
	}
	else if (c==3)
	{
	cout <<"Exit" << endl;
	return f;
}
	
}
int main()
{
	
	queue <int,10> i;
	queue <double,10> d;
	int c1;
	
	cout <<"1-> INterger" << endl;
	cout <<"2-> Double" << endl;
	cout <<"3-> Exit" << endl;
	cout <<"Enter Choice"<< endl;
	
	bool f;
	cin >> c1;
	if(c1!=3){
		int x=0;
			do{
		cout <<"1-> Enqueue" << endl;
	    cout <<"2-> Dequeue" << endl;
	    cout <<"3-> Exit" << endl;
	    cout <<"Enter Choice"<< endl;
	    int c2;
	    cin >> c2;
	switch(c1)
	{
	
	    case 1:
	    	f=i.menu(c2);
	    	if (f)
	    	x=1;
	    	break;
		case 2:
		    f=d.menu(c2);	
			if (f)
	    	x=1;
	    	break;
	    case 3:
	    	cout<<"=======End======"<< endl;
	    	break;
	}
   }while (x!=1);
}
return 0;
}
