#include <iostream>
using namespace std;
template <class T>
class Node
{
	
	public:
			T data;
		Node *next;
		Node(){
			next=NULL;
		}
};

template <class T>
class Stack
{
	Node<T> *first;
	Node<T> *temp;
	public:
		Stack()
		{
			first=NULL;
		}
		void push(T el)
		{
			temp=new Node<T>;
			temp->data=el;
			temp->next=first;
			first=temp;
		}
		T pop()
		{
			if (first==NULL)
			{
				cout <<"Stack is Empty" << endl;
			}
			else
			{
				cout <<"\nElement POP-OUT:";
				temp=first;
				first=first->next;
				return temp->data;
				delete temp;
			}
		}
		void display()
		{
			if (first==NULL)
			{
				cout <<"Empty Stack"<< endl;
			}
			else
			{
				cout <<"Satck is: ";
				for (temp=first;temp!=0;temp=temp->next)
				cout << temp->data <<" ";
				cout << endl;
			}
		}
		void menu(int c);		
};
template <class T>
void Stack<T>::menu(int c)
{
	if (c==1)
	{
		T num;
		cout <<"\n Enter Number to PUSH:";
		cin >>num;
		push(num);
	}
	else if (c==2)
	{
		T num;
		num=pop();
		cout << num << endl;
	}
	else if (c==3)
	{
		display();
	}
}
int main()
{
	Stack <int> i;
	Stack <double> d;
	Stack <char> c;
	Stack <float> f;
	int ch1,ch2;
	do {
	
	cout <<"\n\t Enter Choice";
	cout <<"\n 1.Integer";
	cout <<"\n 2.Double";
	cout <<"\n 3.Char";
	cout <<"\n 4.Float";
	cout <<"\n 5.Exit"<< endl;
	cin  >>ch1;
	cout << endl;
	if (ch1!=5)
    {
		do {
		
		cout <<"\n\tEnter Choice";
		cout <<"\n 1.PUSH";
		cout <<"\n 2.POP";
		cout <<"\n 3.DISPLAY";
		cout <<"\n 4.STEP_BACK";
		cout << endl;
		cin >> ch2;
		cout<<endl;
	switch (ch1)
	{
		case 1:
			i.menu(ch2);
			break;
		case 2:
			d.menu(ch2);
			break;
		case 3:
			c.menu(ch2);
			break;
		case 4:
			f.menu(ch2);
			break;
		}
	}while (ch2!=4);
	}
}while (ch1!=5);

	return 0;
}
