#include<iostream>
#include<math.h>
using namespace std;
class sparse
{
 int sp[4][4],temp[20];
 int n;
  public:
    sparse()
  {
   n=0;
  }
    void insert()
  {
   cout<<"Enter the sparse matrix:\n";
   for(int i=0;i<4;i++)
    for(int j=0;j<4;j++)
     cin>>sp[i][j];
  }
  void create_diagonal()
  {   int ctr=0;
   for(int i=0;i<4;i++)
   {
    for(int j=0;j<4;j++)
    {
     if(i==j)
     {
      temp[ctr]=sp[i][j];
      ctr++;
     }
    }
   }
   cout<<"The resulting matrix is:\n";    for(int i=0;i<=ctr;i++)
   {
    cout<<temp[i]<<" ";
   }
   cout<<endl;
     }
    void create_ltm(int m)
  {
   int ctr=0;
   sp[20][20]={ };
   cout<<"Enter the "<<n<<" enteryies for making lower triangular sparse matrix:\n";
   
   for(int i=0;i<n;i++)
   cin>>temp[i];
   for(int i=0;i<m;i++)
   {
    for(int j=0;j<m;j++)
    {
     if((i>=j)&&(ctr<n))
      
      sp[i][j]=temp[ctr++];
        else
      sp[i][j]=0;
    }
       }
      }
    void create_utm(int m)
  {
   int ctr=0;
   sp[20][20]={0};
   
   cout<<"Enter the "<<n<<" enteries for making upper triangular sparse matrix:\n";
   for(int i=0;i<n;i++)
   cin>>temp[i];
   for(int i=0;i<m;i++)
   {
    for(int j=0;j<m;j++)
    {
     if((i<=j)&&(ctr<n))
      sp[i][j]=temp[ctr++];
     else
      sp[i][j]=0;
    }
       }
      }
    void sym(int m)
  {
   int ctr=0;
   sp[20][20]={0};
  
   int sp1[20][20];
   cout<<"Enter the "<<n<<" enteries for making symmetric sparse matrix:\n";
   for(int i=0;i<n;i++)
   cin>>temp[i];
   for(int i=0;i<m;i++)
   {
    for(int j=0;j<m;j++)
    {
     if(ctr<n)
      sp[i][j]=temp[ctr++];
     else
      sp[i][j]=0;
    }
   }
      for(int i=0;i<m;i++)
   {
    for(int j=0;j<m;j++)
    {
     sp1[j][i]=sp[i][j];
    }
   }
      for(int i=0;i<m;i++)
   {
    for(int j=0;j<m;j++)
    {
     sp[i][j]=(sp[i][j]+sp1[i][j])/2;
    }
   }
     }
    void display(int m)
  {
   for(int i=0;i<m;i++)
   {
    for(int j=0;j<m;j++)
    {
     cout<<sp[i][j]<<" ";
    }
    cout<<endl;
   }
  }
};
int main()
{  int n,cho,m,ctr=0,temp;
 char ch;
 do
 {
   sparse s1;
   cout<<"What u want to make:\n1.diagonal\n2.lower triangular\n3.upper triangular\n4.symmetric\n5.restart\n";
   cin>>cho;
   switch(cho)
   {
    case 1: s1.insert();
      s1.create_diagonal();
         s1.display(n);
         break;
    case 2:cout<<"Enter the order of matrix:\n";
        cin>>m;
        temp=m;
        ctr=0;
        while(temp>0)
        {
         ctr+=temp;
         temp--;
        }
        cout<<"ctr= "<<ctr<<endl;
        if(n<=ctr)
        {
         s1.create_ltm(m);
         s1.display(m);
        }
        else
         cout<<"more than required entries:\n";
        break;
    case 3:cout<<"Enter the order of matrix:\n";
        cin>>m;
        temp=m;
        ctr=0;
        while(temp>0)
        {
         ctr+=temp;
         temp--;
        }
        cout<<"ctr= "<<ctr<<endl;
        if(n<=ctr)
        {
         s1.create_utm(m);
         s1.display(m);
        }
        else
         cout<<"more than required entries:\n";
        break;
    case 4:cout<<"Enter the order of matrix:\n";
        cin>>m;
        if(((m*m)-n)>=(m*m)/2)
        {
         s1.sym(m);
         s1.display(m);
        }
        else
         cout<<"more than required entries for such a sparse matrix\n";
        break;
    case 5:continue;
        break;
    default: cout<<"Enter choice from 1 to 5 only:\n";
   }
   cout<<"Want to enter more:\n";
   cin>>ch;
   }while(ch=='y');
}
