#include<iostream>
using namespace std;
template<class T>
class Array{
	int size;
	T *arr;
	public:
		void getData();
		void showData();
		void cases();
		int partition(int lb,int ub);
		void quickSort(int lb,int ub);
		void merge(int first,int mid,int last);
		void mergeSort(int first,int last);
};
template<class T>
void Array<T>::getData(){
	cout<<"\nEnter the size of the ARRAY ::\t";
	cin>>size;
	arr=new T[size];
	cout<<"\nEnter the ARRAY elements ::\t";
	for(int i=0;i<size;i++)
		cin>>arr[i];
}
template<class T>
void Array<T>::showData(){
	for(int i=0;i<size;i++)
		cout<<arr[i]<<"   ";
}
template<class T>
void Array<T>::merge(int first,int mid,int last){
	T *temp=new T[size];
	int i=first,j=mid+1,k=0;
	while(i<=mid&&j<=last){
		if(arr[i]<arr[j])
			temp[k++]=arr[i++];
		else
			temp[k++]=arr[j++];
	}
	while(i<=mid)
		temp[k++]=arr[i++];
	while(j<=last)
		temp[k++]=arr[j++];
	for(int m=0;m<k;m++)
		arr[first+m]=temp[m];
}
template<class T>
void Array<T>::mergeSort(int first,int last){
	int mid;
	if(first<last){
		mid=(first+last)/2;
		mergeSort(first,mid);
		mergeSort(mid+1,last);
		merge(first,mid,last);
	}
}
template<class T>
int Array<T>::partition(int lb,int ub){
	T x=arr[lb],temp;
	int down=lb,up=ub;
	while(down<up){
		while(arr[down]<=x&&down<ub)
			down++;
		while(arr[up]>x)
			up--;
		if(up>down){
			temp=arr[down];
			arr[down]=arr[up];
			arr[up]=temp;
		}
	}
	arr[lb]=arr[up];
	arr[up]=x;
	
	return up;
}
template<class T>
void Array<T>::quickSort(int lb,int ub){
	int pos;
	if(lb<ub){
		pos=partition(lb,ub);
		quickSort(lb,pos-1);
		quickSort(pos,ub); 
	}
}
template<class T>
void Array<T>::cases(){
	int choice;
	do{
		cout<<"\n#### ** #MENU 2# ** ####"
			<<"\n1). Quick Sort"
			<<"\n2). Merge Sort"
			<<"\n3). EXIT"
			<<"\n\n==>> Enter your choice :: \t";
		cin>>choice;
		switch(choice){
			case 1:	getData();
					quickSort(0,size-1);
					cout<<"\n==>> SORTED ARRAY ::\t";
					showData();
					break;
			case 2:	getData();
					mergeSort(0,size-1);
					cout<<"\n==>> SORTED ARRAY ::\t";
					showData();
					break;
			case 3:	cout<<"\nEXIT!!!";
					break;
			default:cout<<"\nWRONG CHOICE ENTERED!!!";
					break;
			
		}
	}while(choice!=3);
}
int main(){
	int choice;
	do{
		cout<<"\n#### ** #MENU 1# ** ####\n"
			<<"\n1). Integer"
			<<"\n2). Float"
			<<"\n3). Double"
			<<"\n4). Long"
			<<"\n5). Character"
			<<"\n6). EXIT"
			<<"\n\n==>> Enter your choice :: \t";
		cin>>choice;
		switch(choice){
			case 1:	{
						Array<int>obj;
						obj.cases();
					}
					break;
			case 2:	{
						Array<float>obj;
						obj.cases();
					}
					break;
			case 3:	{
						Array<double>obj;
						obj.cases();
					}
					break;
			case 4:	{
						Array<long>obj;
						obj.cases();
					}
					break;
			case 5:	{
						Array<char>obj;
						obj.cases();
					}
					break;
			case 6:	cout<<"\nEXIT !!!!";
					break;
			default:cout<<"\nWRONG CHOICE ENTERED!!!!";
					break;
		}
	}while(choice!=6);
}
