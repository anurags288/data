#include <iostream>
using namespace std;
class last
{
	
	public:
	void insert(int n[],int size);
	void bsort(int n[],int size);
	void ssort(int n[],int size);
	void isort(int n[],int size);
	void msort(int n[],int size,int b[],int size1);
	void qsort();
	void lsearch(int n[],int size,int s);
	void bsearch(int n[],int size,int s);	
	void display(int n[],int size);
};
void last:: insert(int n[],int size)
{
	int i;
	
	cout <<"Enter Array: ";
	for (i=0;i<size;i++)
	{
		cin >> n[i];
	}
	cout <<endl;
}
void last::bsort(int n[],int size)
{
	int i,j,temp;
	for (i=0;i<=(size-2);i++)
	{
		for (j=0;j<=(size-2)-i;j++)
		{
			if (n[j] > n[j+1])//Ascending
			{
				temp=n[j];
				n[j]=n[j+1];
				n[j+1]=temp;
			}
		}
	}
	
}
void last::ssort(int n[],int size)
{
	int i,j,sml,pos,t;
	for (i=0;i<=(size-2);i++)
	{
		sml=n[i];
		pos=i;
		for (j=i+1;j<=(size-1);j++)
		{
			if (n[j]<sml)
			{
				sml=n[j];
				pos=j;
			}
			t=n[i];
			n[i]=n[pos];
			n[pos]=t;
		}
	}

}
void last::bsearch(int n[],int size,int s)
{
	int mid,beg,end;
	
	beg=0;
	end=size-1;
	while(beg<=end)
	{
		mid=(beg+end)/2;
		if (n[mid]==s)
		{
			cout <<"Found at: "<< mid<<endl;
			break;
		}
		else if (s<n[mid])//ascending sort
		{
			end=mid-1;
		}
		else
		{
			beg=mid+1;
		}
	}
}
void last::lsearch(int n[],int size,int s)
{
	insert(n,size);
	int i,f=0;
	for (i=0;i<size;i++)
	{
		if (n[i]==s)
		{
			f=i;
			break;
		}
	}
	cout <<"Found at "<<f <<endl;
}
void last::display(int n[],int size)
{
	int i;
	cout << "Array is: "<<endl;
	for (i=0;i<size;i++)
	{
		cout<<n[i]<<" ";
	}
}
void last::isort(int n[],int size)
{

	int i,h,temp;
	for (i=1;i<size;i++)
	{
		temp=n[i];
		h=i-1;
		while(temp<n[h] && h>=0)
		{
			n[h+1]=n[h];
			h--;
		}
		n[h+1]=temp;
	}
}
void last::msort(int n[],int size,int b[],int size1)
{
	
	int x=size+size1;
	int c[x];
	int np=0,bp=0,cp=0;
	for (cp=0;np<size && bp<size1;cp++)
	{
		if (n[np]<b[bp])
		{
			c[cp]=n[np];
			np++;
		}
		else if (n[np]>b[bp])
		{
			c[cp]=b[bp];
			bp++;
		}
	}
	while (np<size)
	{
		c[cp]=n[np];
		cp++;
		np++;
	}
	while (bp<size1)
	{
		c[cp]=b[bp];
		cp++;
		bp++;
	}
	display(c,x);
}
int main()
{
	last l;
	int size,size1;
	int n[10],b[10],c[10];
	cout <<"Enter Choice"<<endl;
	cout <<"1.Buble Sort"<<endl;
	cout <<"2.Selection Sort"<<endl;
	cout <<"3.insertion Sort"<<endl;
	cout <<"4.binary search"<<endl;
	cout <<"5.linear search"<<endl;
	cout <<"6.merge sort"<<endl;
	//cout <<"quick sort"<<endl;
	int ch;
	cin>>ch;
	switch(ch)
	{
		case 1:
			cout<<endl;
	        cout <<"Enter Array Size: ";
	        cin >>size;
			l.insert(n,size);
			l.bsort(n,size);
		    cout <<"Bubble Sort:" <<endl;
	        l.display(n,size);
			break;
		case 2:
			cout<<endl;
	        cout <<"Enter Array Size: ";
	        cin >>size;
			l.insert(n,size);
			l.ssort(n,size);
		    cout <<"Selection Sort: "<<endl;
	        l.display(n,size);
	        break;
		case 3:
			cout<<endl;
	        cout <<"Enter Array Size: ";
	        cin >>size;
			l.insert(n,size);
			l.isort(n,size);
		    cout <<"Insertion Sort: "<<endl;
	        l.display(n,size);
			break;
		case 4:
			cout<<endl;
	        cout <<"Enter Array Size: ";
	        cin >>size;
			l.insert(n,size);
			l.bsort(n,size);
			int s;
			cout<<"Enter Search element: "<<endl;
			cin>>s;
			l.bsearch(n,size,s);
		    cout <<"Binary Search "<<endl;
			break;
		case 5:
			cout<<endl;
	        cout <<"Enter Array Size: ";
	        cin >>size;
			l.insert(n,size);
			int s1;
			cout<<"Enter Search element: "<<endl;
			cin>>s1;
			l.lsearch(n,size,s1);
		    cout <<"Linear Search "<<endl;
			break;
		case 6:
			cout<<endl;
	        cout <<"Enter Array Size: ";
	        cin >>size;
			l.insert(n,size);
			cout<<endl;
	        cout <<"Enter Array Size: ";
	        cin >>size1;
			l.insert(b,size1);
			l.msort(n,size,b,size1);
			cout <<"Merge Sort: "<<endl;
			break;	
	}
	return 0;
}
