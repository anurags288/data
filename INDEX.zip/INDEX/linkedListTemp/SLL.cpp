#include <iostream>
using namespace std;
template <class T>
class node
{
	public:
	T data;
	node<T> * next;
	node()
	{
		next=NULL;
	}
};
template <class T>
class SLL
{
	public:
		node<T>* head,*tail;
		SLL()
		{
			head=tail=NULL;
		}
	  void addAtBeg(T num);//
	  void addAtEnd(T num);//
	  void delFromBeg();//
	  void delFromEnd();//
	  void reverse();
	  void display();//
	  void concat(SLL);
	  bool delNode(T num);//
	  bool search(T num);//
	  //void insert(int pos,T num);
};
template <class T>
void SLL<T>::addAtBeg(T num)
{
	node<T>* temp=new node<T>();
	temp->data=num;
	if (head==NULL)
	{
		head=tail=temp;
	}
	else
	{
		temp->next=head;
		head=temp;
	}
	cout <<"Added Successfully"<< endl;
	display();
}
template <class T>
void SLL<T>::addAtEnd(T num)
{
	node<T>* temp=new node<T>();
	temp->data=num;
	if (tail!=NULL)
	{
		tail->next=temp;
		tail=temp;
	}
	else
	tail=head=temp;
	
	cout <<"Added Successfully"<< endl;
}
template <class T>
void SLL<T>::delFromBeg()//will call only if head is there
{
	node<T>* temp=head;
	T el=head->data;
	if (head!=NULL)
	{
	if (head==tail)
	{
		head=tail=NULL;
	}
	else
	head=head->next;
	
	delete temp;
	cout <<"Deleted Successfully"<< endl;
	}
	else
	{
		cout <<"Empty! Cannot delete"<<endl;
	}
}
template <class T>
void SLL<T>::delFromEnd()
{
	T num=tail->data;
	if (head==NULL)
	cout <<"Empty! Cannot delete"<<endl;
	else
	if (head==tail)//only one node
	{
		delete head;
		head=tail=0;
	}
	else
	{
		node<T>*temp;
		for (temp=head;temp->next!=tail;temp=temp->next);
		delete tail;
		tail=temp;
		tail->next=NULL;	
	}
	cout <<"Deleted Successfully"<< endl;	
}
template <class T>
bool SLL<T>::search(T num)
{
	node<T>* temp;
	for (temp=head;temp!=NULL;temp=temp->next)
	{
		if (temp->data==num)
		return true;
	}
	return false;
}
template <class T>
bool SLL<T>::delNode(T num)
{
	if (head==NULL)
		cout <<"Empty! Cannot delete"<<endl;
	else{
	
	if (head->data==num && head==tail)
	{
		delete head;
		head=tail=NULL;
		return true;
	}
	else if (head->data==num)
	{
		node<T>* temp=head;
		head=head->next;
		delete temp;
		return true;
	}
	else
	{
		node<T>* temp, *prev;
		for (prev=head,temp=head->next; temp!=NULL && !(temp->data==num); prev=prev->next,temp=temp->next);
		if (temp!=NULL)
		{
			prev->next=temp->next;
			if (temp==tail)
			tail=prev;
			delete temp;
			return true;
		}
	}
}
	return false;
}
template <class T>
void SLL<T>::display()
{
	cout <<"List is: ";
	for (node<T>*temp=head; temp!=NULL; temp=temp->next)
	cout <<temp->data<<" ";
	cout << endl;	
}
template <class T>
void SLL<T>::reverse()
{
	if (head==NULL)
	{
		cout <<"Empty List" << endl;
		return;
	}
	cout<<"\n====BEFORE REVERSING===="<<endl;
	display();
	cout<<"\n====AFTER REVERSING====="<<endl;
		node<T> * p1,*p2,*p3;
		p1=head;
		p2=p1->next;
		p1->next=NULL;//since we want head to go at last
		while (p2!=NULL)
		{
			p3=p2->next;
			p2->next=p1;
			p1=p2;
			p2=p3;
		}
		head=p1;
	display();
	cout <<"\n========================";
	cout << endl;
	
}
/*template <class T>
void SLL<T>::concat(SLL<T> list)
{
	cout <<"Enter List to Concatenate"<< endl;
	
	char ch;
	do
	{
		T num;
		cout<<"\nEnter data:";
		cin>>num;
	    list.addAtBeg(num);
		cout<<"\nYou want to add more elts to list?(y/n):";
		cin>>ch;
	}while(ch=='y');
	node<T>*temp=list.head;
	while(temp!=NULL)
	{
		addAtEnd(temp->data);
		temp=temp->next;
	}
	cout<<"============================================="<<endl;
	cout <<"Concat List is: "<< endl;
	display();
	cout<<"============================================="<<endl;
}*/
template<class T>
void SLL<T>::concat(SLL<T> tList)
{
	cout<<"\nEnter the list to be concatenated....";
	char ch;
	do{
		T num;
		cout<<"\nEnter data:";
		cin>>num;
		tList.addAtBeg(num);
		cout<<"\nYou want to add more elts to list?(y/n):";
		cin>>ch;
	}while(ch=='y');

	node<T> *temp=tList.head;
	while(temp!=NULL)
	{
		addAtEnd(temp->data);
		temp=temp->next;
	}

	cout<<"\nConacatenated List";
	cout<<"\n-------------------------------------------------";
	display();
	cout<<"\n-------------------------------------------------";
}

//============================================

int main()
{
	int ch,ch1;
	do{
		SLL<int> si;
		SLL<float> sf;
		SLL<char> sc;
		cout<<"\n\n\t\tChoose a data type";
		cout<<"\n\n1.Integer";
		cout<<"\n2.Float";
		cout<<".\n3.Character";
		cout<<"\n4.Exit";
		cout<<"\nEnter your choice:";
		cin>>ch1;
		if(ch1!=4)
	        do{
		      cout<<"\n\n\t\tSINGLY LINKED LIST";
		      cout<<"\n1.Add at begining";
		      cout<<"\n2.Add at end";
		      cout<<"\n3.Delete from begining";
		      cout<<"\n4.Delete from end";
		      cout<<"\n5.Delete a node";
		      cout<<"\n6.Search ";
		      cout<<"\n7.Display list";
		      cout<<"\n8.Reversing the list";
		      cout<<"\n9.Conactenate two lists";
		      //cout<<"\n10.Insert at a location";
		      cout<<"\n11.Return";
		      cout<<"\nEnter your choice:";
		      cin>>ch;
		switch(ch)
		{
	        case 1:
		    {
			if(ch1==1)
			{
			   int num;
			   cout<<"\nEnter the data:";
			   cin>>num;
			   si.addAtBeg(num);
			}
			else
			if(ch1==2)
			{
			   float num;
			   cout<<"\nEnter the data:";
			   cin>>num;
			   sf.addAtBeg(num);
			}
			else
			if(ch1==3)
			{
			   char num;
			   cout<<"\nEnter the data:";
			   cin>>num;
			   sc.addAtBeg(num);
			}
			cout<<"\nData added successfully";
			break;
		   }
		    case 2:
		   {
			if(ch1==1)
			{
			   int num;
			   cout<<"\nEnter the data:";
			   cin>>num;
			   si.addAtEnd(num);
			}
			else
			if(ch1==2)
			{
			   float num;
			   cout<<"\nEnter the data:";
			   cin>>num;
			   sf.addAtEnd(num);
			}
			else
			if(ch1==3)
			{
			   char num;
			   cout<<"\nEnter the data:";
			   cin>>num;
			   sc.addAtEnd(num);
			}
			cout<<"\nData added successfully";
			break;
		   }
		    
			case 3:
			if(ch1==1)
			  si.delFromBeg();
			else
			if(ch1==2)
			  sf.delFromBeg();
			else
			if(ch1==3)
			  sc.delFromBeg();
			break;
		    
			case 4:
			if(ch1==1)
			  si.delFromEnd();
			else
			if(ch1==2)
			  sf.delFromEnd();
			else
			if(ch1==3)
			  sc.delFromEnd();
			break;
		    
			case 5:
			{
			 if(ch1==1)
			 {
			    int num;
			    cout<<"\nEnter the data to be deleted:";
			    cin>>num;
			    bool flag=si.delNode(num);
			    if(flag==false)
			      cout<<"\nData not found";
			    else
			      cout<<"\nNode deleted";
			}
			else
			if(ch1==2)
			{
			    float num;
			    cout<<"\nEnter the data to be deleted:";
			    cin>>num;
			    bool flag=sf.delNode(num);
			    if(flag==false)
			      cout<<"\nData not found";
			    else
			      cout<<"\nNode deleted";
			}
			else
			if(ch1==3)
			 {
			    char num;
			    cout<<"\nEnter the data to be deleted:";
			    cin>>num;
			    bool flag=sc.delNode(num);
			    if(flag==false)
			      cout<<"9p";//36+\nData not found";
			    else
			      cout<<"\nNode deleted";
			}

			break;
		}
		    case 6:
			{
			 if(ch1==1)
			 {
			    int num;
			    cout<<"\nEnter the data to be deleted:";
			    cin>>num;
			    bool flag=si.search(num);
			    if(flag==false)
			      cout<<"\nData not found";
			    else
			      cout<<"\nData is present";
			}
			else
			if(ch1==2)
			{
			    float num;
			    cout<<"\nEnter the data to be deleted:";
			    cin>>num;
			    bool flag=sf.search(num);
			    if(flag==false)
			      cout<<"\nData not found";
			    else
			      cout<<"\nData is present";
			}
			else
			if(ch1==3)
			 {
			    char num;
			    cout<<"\nEnter the data to be deleted:";
			    cin>>num;
			    bool flag=sc.search(num);
			    if(flag==false)
			      cout<<"\nData not found";
			    else
			      cout<<"\nData is present";
			}

			break;
		}
		    case 7:
			if(ch1==1)
			  si.display();
			else
			if(ch1==2)
			  sf.display();
			else
			if(ch1==3)
			  sc.display();
			break;

		   case 8:if(ch1==1)
			  si.reverse();
			else
			if(ch1==2)
			  sf.reverse();
			else
			if(ch1==3)
			  sc.reverse();

			break;

		   case 9:
		     {
			if(ch1==1)
			{
				SLL<int> t;
				si.concat(t);
			}
			else
			if(ch1==2)
			{
				SLL<float> t;
				sf.concat(t);
			}
			else
			if(ch1==3)
			{
				SLL<char> t;
				sc.concat(t);
			}

			break;
		     }

		  
	           /*  case 10:
		    {
			if(ch1==1)
			{
			   int num,pos;
			
			   cout<<"\nEnter the data:";
			   cin>>num;
			   cout<<"\nEnter the position:";
			   cin>>pos;
			   si.insert(pos,num);
			}
			else
			if(ch1==2)
			{
			   int pos;
			   float num;
			   cout<<"\nEnter the data:";
			   cin>>num;
			   cout<<"\nEnter the position:";
			   cin>>pos;
			   sf.insert(pos,num);
			}
			else
			if(ch1==3)
			{
			   int pos;
			   char num;
			   cout<<"\nEnter the data:";
			   cin>>num;
			   cout<<"\nEnter the position:";
			   cin>>pos;
			   sc.insert(pos,num);
			}
			
			break;
		   }*/
		  case 11:
			break;

		}

	}while(ch!=11);

	}while(ch1!=4);
return 0;
}


