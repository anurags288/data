#include<iostream>
using namespace std;
const int MAX=10;

template<class T>
class Stack
{
	public:
    T stck[MAX];
    int s;
    int top;
    
    Stack();
    void push(T);
    T pop(int&);
    bool empty();
    void display();
 
};
template<class T>
   void Stack<T>::display()
    {
    		for (int i=0;i<MAX;i++)
    	cout << stck[i] <<" ";
	}

    template<class T>
    bool Stack<T>::empty()
    {
        if(top==-1)
            return true;
        else
            return false;
    }
    template<class T>
    Stack<T>::Stack()
    {
        top=-1;
    }

    template<class T>
    void Stack<T>::push(T item)
    {
        if(top==MAX-1)
            cout<<"\n Stack is full";
        else
            stck[++top]=item;
    }

    template<class T>
    T Stack<T>::pop(int& flag)
    {   T num;
        if(top==-1)
        {
            flag=1;
            return num;
        }
        else
        {
                flag=0;
                return stck[top--];
        }
    }
    int main ()
    {
    	Stack <int> s;
    	for (int i=0;i<MAX;i++)
    	s.push(i);
    	cout << "======================"<<endl;
        s.display();
    	return 0;
	}
