#include <iostream>
using namespace std;
template <class T>
class node
{
	public:
	node<T>* next;
	T data;
	node()
	{
		next=NULL;
	}
};
template <class T>
class CLL
{
	node<T>* tail;
	public:
		CLL();
		void addAtBeg(T);
		void addAtEnd(T);
		void delFromBeg();
		void delFromEnd();
		void reverse();
		void display();
		void menu(int);
};
template <class T>
CLL<T>::CLL()
{
	tail=NULL;
}
template <class T>
void CLL<T>::addAtBeg(T num)
{
	node<T>* temp=new node<T>();
	temp->data=num;
	if (tail==NULL)
	{
		tail=temp;
		tail->next=tail;
	}
	else
	{
		temp->next=tail->next;
		tail->next=temp;
	}
}
template <class T>
void CLL<T>::addAtEnd(T num)
{
	node<T>* temp=new node<T>();
	temp->data=num;
	if (tail==NULL)
	{
		tail=temp;
		tail->next=tail;
	}
	else
	{
		temp->next=tail->next;
		tail->next=temp;
		tail=temp;
	}
}
template <class T>
void CLL<T>::delFromBeg()
{
	node<T>* temp;
	if (tail==NULL)
	{
		cout <<"Empty List" << endl;
		return;
	}
	else if (tail->next==tail)
	{
		delete tail;
		tail=NULL;
	}
	else
	{
		temp=tail->next;
		tail->next=temp->next;
		delete temp;
	}
	cout<<"Deleted Successfully"<< endl;
}
template <class T>
void CLL<T>::delFromEnd()
{
	if(tail==NULL)
	{
		cout<<"Empty List"<< endl;
		return;
	}
	else if (tail->next==tail)
	{
		cout<<"\nDeleted information:"<<tail->data;
		delete tail;
		tail=NULL;
	}
	else
	{
	node<T>* temp;
	for (temp=tail->next;temp->next!=tail;temp=temp->next);
	temp->next=tail->next;
	delete tail;
	tail=temp;
    }
    cout <<"Deleted Successfully"<< endl;
}
template <class T>
void CLL<T>::reverse()
{
	
	if(tail==NULL)
		display();
	else
	{
		display();
		node<T> *temp=tail->next;
		
		node<T>* p1,*p2,*p3;
		p1=tail->next;
		p2=p1->next;          
	
	do
	{
		p3=p2->next;
		p2->next=p1;
		p1=p2;
		p2=p3;
	}while(p1!=tail);
		p2->next=tail;
		tail=p2;
		display();
	}
/*	if (tail==NULL)
	{
		cout <<"Empty List"<< endl;
	}
	else
	{
		cout <<" Before "<< endl;
	    display();
		node<T>*p1,*p2,*p3,*temp;
		temp=tail->next;
		p1=tail->next;
		p2-p1->next;
		do
		{
			p3=p2->next;
			p2->next=p1;
			p1=p2;
			p2=p3;
		}while(p1!=tail);
		p2->next=tail;//-->intial tail before reversing
		tail=p2;
		cout <<" After " << endl;
		display();
	}*/
}
template <class T>
void CLL<T>::display()
{
	if(tail==NULL)
		cout<<"\nList is empty";
	else
	{
		node<T> *temp=tail->next;
		cout<<"\nList is:";
		do
		{
			cout<<temp->data<<" ";
		 	temp=temp->next;
		}	while(temp!=tail->next);
	}
	/*if (tail==NULL)
	{
		cout <<"Empty List"<< endl;
	}
	else
	{
		cout<<"List is: ";
		for (node<T>* temp=tail->next;  temp!=tail->next;  temp=temp->next)
		cout <<temp->data<<" ";
		cout<< endl;
	}*/
}
template <class T>
void CLL<T>::menu(int c)
{
	node<T>* temp;
	T num;
	switch(c)
	{
		case 1:
			cout <<"Enter data:"<< endl;
			cin>>num;
			addAtBeg(num);
			display();
			break;
		case 2:
			cout <<"Enter data:"<< endl;
			cin>>num;
			addAtEnd(num);
			display();
			break;
		case 3:
		    delFromBeg();
		    display();
			break;
		case 4:
		    delFromEnd();
		    display();
			break;
		case 5:
		    display();
		case 6:
		    reverse();
			break;
		case 7:
		    break;	
	}
}
int main()
{
	int ch1,ch;
		CLL<int> ci;
		CLL<float> cf;
		CLL<char> cc;
		do
		{
		cout<<"\n\n\t\tCHOOSE A DATA TYPE\n";
		cout<<"\n1.Integer";
		cout<<"\n2.Float";
		cout<<"\n3.Character";
		cout<<"\n4.Exit";
		cout<<"\nEnter your choice:";
		cin>>ch;
		if(ch!=4)
		{
			do
			{
			cout<<"\n\n\t\tCIRCULAR LINKED LIST\n";
			cout<<"\n1.Add at beginning";
			cout<<"\n2.Add at end";
			cout<<"\n3.Delete from beginning";
			cout<<"\n4.Delete from end";
			cout<<"\n5.Display";
			cout<<"\n6.Reverse";
			cout<<"\n7.Return";
			cout<<"\nEnter your choice:";
			cin>>ch1;
			switch(ch)
			{
				case 1:
					ci.menu(ch1);
					break;
				case 2:
					cf.menu(ch1);
					break;
				case 3:
					cc.menu(ch1);
					break;
				case 4:
					break;
			}
				
			}while(ch1!=7);
		}
	}while(ch!=4);
	return 0;
}

