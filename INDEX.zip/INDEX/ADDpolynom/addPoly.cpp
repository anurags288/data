 #include<iostream>
 using namespace std;
 template<class T>
 class node
 {
 	public:
 	node<T> *next;
 	int power;
 	int coeff;
 };
 template<class T>
 class poly
 {
 	node<T> *head;
 	int n;
 	public:
 		poly()
 		{
 			head=NULL;
		 }
		 void create()
		 {
		 	char ch;
		 	head=new node<T>;
		 	cout<<"enter power and coefficient of first node "<<endl;
		 	cin>>head->power;
		 	cin>>head->coeff;
		 	head->next=NULL;
		 do{
		 	cout<<"want to add more data"<<endl;
		 	cin>>ch;
		 if(ch=='y')
		 {
		 insert();}
		 }while(ch=='y');
		 }
		 void insert()
		 {
		 	node<T> *prev, *current, *temp;
		 	temp=new node<T>;
		 	cout<<"enter power and coefficient respectively"<<endl;
		 	cin>>temp->power;
		 	cin>>temp->coeff;
		 	int b=temp->power;
		 	temp->next=NULL;//dangling pointer
		 	prev=NULL;
		 	current=head;
		 	while((current!=NULL)&&(current->power<b))
		 	{
		 		prev=current;
		 		current=current->next;
			 }
			 if(prev==NULL)
			 {
			 	temp->next=head;
			 	head=temp;
			 }
			 else if(current==NULL)
			 {
			 	prev->next=temp;
			 }
			 else
			 {
			 	 temp->next=current;
			 	 prev->next=temp;
			 }
		 }
		 
		 void add(poly p1,poly p2)
		 {
		 	node<T> *curr1,*curr2,*curr3,*temp;
		 	curr1=p1.head;
		 	curr2=p2.head;
		 	while((curr1!=NULL)&&(curr2!=NULL))
		 	{
		 		if(curr1->power==curr2->power)
		 		{
		 			temp=new node<T>;
		 			temp->power=curr1->power;
		 			temp->coeff=curr1->coeff+curr2->coeff;
		 			temp->next=NULL;
		 			curr1=curr1->next;
		 			curr2=curr2->next;
				 }
				 else if(curr1->power<curr2->power)
				 {
				 	temp=new node<T>;
				 	temp->power=curr1->power;
				 	temp->coeff=curr1->coeff;
				 	temp->next=NULL;
				 	curr1=curr1->next;
				 }
				 else if(curr2->power<curr1->power)
				 {
				 	temp=new node<T>;
				 	temp->power=curr2->power;
				 	temp->coeff=curr2->coeff;
				 	temp->next=NULL;
				 	curr2=curr2->next;
				 }
				 
				 if(head==NULL)
				 {
				 	head=temp;
				 	curr3=head;
				 }
				 else
				 {
				 	curr3->next=temp;
				 	curr3=temp;
				 }
			 }
			 if(curr1!=NULL)
			 {
			 	while(curr1!=NULL)
			 	{
			 		temp=new node<T>;
			 		temp->power=curr1->power;
			 		temp->coeff=curr1->coeff;
			 		temp->next=NULL;
			 			curr1=curr1->next;
			 			curr3->next=temp;
			 			curr3=temp;
				 }
			 }
			 else if(curr2!=NULL)
			 {
			 	while(curr2!=NULL)
			 	{
			 		temp=new node<T>;
			 		temp->power=curr2->power;
			 		temp->coeff=curr2->coeff;
			 		temp->next=NULL;
			 			curr2=curr2->next;
			 			curr3->next=temp;
			 			curr3=temp;
			 }
		 }
 }
 void display()
 {
 	node<T> *current;
 	current=this->head;
 	while(current!=NULL)
 	{
 		cout<<current->coeff<<"x^"<<current->power<<"+";
		current=current->next;
	 }
	 cout<<endl;
 }
};
int main()
{
	poly<int>p1,p2,p3;
	cout<<"Enter data of first polynomial"<<endl;
	p1.create();
	cout<<"enter data of second polynomial"<<endl;
	p2.create();
	p1.display();
	p2.display();
	p3.add(p1,p2);
	cout<<"Resulting polynomial"<<endl;
	p3.display();
}
