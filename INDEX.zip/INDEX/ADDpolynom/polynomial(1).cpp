#include <iostream>
using namespace std;
template <class t>
class node
{
	public:
	node<t>* next;
	t base,power;
	
		node()
		{
			next=NULL;
		}
};
template <class t>
class P
{
		node<t>* head;
		t b,p;
		char c;
		public:
			P()
			{
				head=NULL;
			}
			void create()
			{
				
				cout <<"Enter base and power for Polynomial"<< endl;
				cin >>b;
				cin >>p;
				head=new node<t>();
				head->base=b;
				head->power=p;
				do{
					cout<<"Do you want to enter more:(y/n)"<<endl;
					cin>>c;
					if (c=='y')
					{
						cout <<"Enter base and power for Polynomial"<<endl;
						cin >>b;
						cin>>p;
						insert(b,p);
					}
					
				}while(c=='y');
			}
			void insert(t b,t p)
			{
				node<t> *cnode,*pnode;
				node<t>* temp=new node<t>();
				temp->base=b;
				temp->power=p;
				t num=b;
				temp->next=NULL;
				cnode=head;
				pnode=NULL;
				while (cnode!=NULL && cnode->power < num)
				{
					pnode=cnode;
					cnode=cnode->next;
				}
				if (pnode==NULL)
				{
					temp->next=head;
					head=temp;
				}
				else if (cnode==NULL)
				{
					pnode->next=temp;
				}
				else //if in between
				{
					temp->next=cnode;
					pnode->next=temp;
				}
			}
			void add(P p1,P p2)
			{
				node<t> *c1,*c2,*c3,*temp;
				c1=p1.head;
				c2=p2.head;
				while (c1!=NULL && c2!=NULL)
				{
					if(c1->power==c2->power)
					{
						temp=new node<t>;
						temp->power=c1->power;
						temp->base=c1->base+c2->base;
						temp->next=NULL;
						c1=c1->next;
						c2=c2->next;
					}
					else if (c1->power < c2->power)
					{
						temp=new node<t>;
						temp->power=c1->power;
						temp->base=c1->base;
						temp->next=NULL;
						c1=c1->next;
					}
					else if (c2->power < c1->power)
					{
						temp=new node<t>;
						temp->power=c2->power;
						temp->base=c2->base;
						temp->next=NULL;
						c2=c2->next;
					}
					if (head==NULL)
				{
					head=temp;
					c3=head;
				}
				else
				{
					c3->next=temp;
					c3=temp;
				}
			}
				
				if (c1!=NULL)
				{
					while (c1!=NULL)
					{
						temp=new node<t>();
						temp->power=c1->power;
						temp->base=c1->base;
						temp->next=NULL;
						c1=c1->next;
						c3->next=temp;
						c3=temp;
					}
				}
				else if (c2!=NULL)
				{
					while (c2!=NULL)
					{
						temp=new node<t>();
						temp->power=c2->power;
						temp->base=c2->base;
						temp->next=NULL;
						c2=c2->next;
						c3->next=temp;
						c3=temp;
					}
				}
			}
			void display()
			{
				node<t> *temp;
				temp=this->head;
				while (temp!=NULL)
				{
					cout <<temp->base<<"x^"<<temp->power<<" + ";
					temp=temp->next;
				}
				cout<< endl;
			}
};
int main()
{
	P <int> po1,po2,po3;
	cout<<"Enter Polynomial 1:"<<endl;
	po1.create();
	
	cout<<"Enter Polynomial 2:"<<endl;
	po2.create();
	
	po1.display();
	po2.display();
	po3.add(po1,po2);
	cout<<"Final Polynomial: "<<endl;
	po3.display();
	return 0;
}
