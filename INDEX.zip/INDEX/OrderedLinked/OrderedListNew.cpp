#include<iostream>
using namespace std;
template<class T>
class Node
{ public:
	T data;
	Node<T> *next;
};
template<class T>
class List
{
	Node<T> *head;
	public:
		List()
		{
			head=NULL;
		}
		void create();
		void insert(T n);
		void display();
		void delete1();
		void merge(List,List,List &);
};
template<class T>
void List<T>::create()
{ char ch;
int n;
	
	head=new Node<T>;
	cout<<"enter data in first node"<<endl;
	cin>>head->data;
	head->next=NULL;
	do
	{
		cout<<"Do you want to add more elements(y/n)"<<endl;
		cin>>ch;
if(ch=='y')
{ cout<<"enter element to be added"<<endl;
cin>>n;
insert(n);
	}
	}while(ch=='y');
	
}
template<class T>
void List<T>:: insert(T n)
{
	Node<T> *temp,*prev,*current;
	temp=new Node<T>;
	temp->data=n;
	temp->next=NULL;
	prev=NULL;
	current=head;
	while((current!=NULL)&&(current->data < temp->data))
	{
		prev=current;
		current=current->next;
	}
	if(prev==NULL)
	{
		temp->next=head;
		head=temp;
	}
	else if(current==NULL)
	{
		prev->next=temp;
		
	}
	else
	{
		temp->next=current;
		prev->next=temp;
	}
}

template<class T>
void List<T>::delete1()
{ int n;
Node<T> *s,*temp;
cout<<"enter element to be deleted"<<endl;
cin>>n;
if (head->next==NULL && head->data==n)
{
	delete head;
	head=NULL;
}
else if (head->data==n)
{
	head=head->next;
	delete head;
}
else
{
	for (s=head,temp=head->next; temp!=NULL && !(temp->data==n); s=s->next,temp=temp->next);
	if (temp!=NULL)
	{
		s->next=temp->next;
		delete temp;
	}
}
/*while(s->next!=NULL)
{
	if(s->next->data==n)
	{
		temp=s->next;
		s->next=temp->next;
		delete(temp);
	}
	s=s->next;
}*/
	display();
}
template<class T>
void List<T>::display()
{
	Node<T> *temp;
	temp=head;
	while(temp->next!=NULL)// 1 2 3 null
	{
	cout<<temp->data<<" ";	
	temp=temp->next;
    }
    cout<<temp->data<<endl;
}
template<class T>
void List<T>::merge(List l1, List l2, List& l3)
{
	Node<T> *p,*q;
	p=l1.head;
	q=l2.head;
	int dat;
	while(p!=NULL && q!=NULL)
	{
		if(p->data>q->data)
		{
		dat=q->data;
		l3.insert(dat);
		q=q->next;
	}
	else
	{
		dat=p->data;
		l3.insert(dat);
		p=p->next;
	}
}
if(p==NULL)
{
	while(q!=NULL)
	{
		dat=q->data;
		l3.insert(dat);
	q=q->next;
	}
}
else
{
	while(p!=NULL)
	{
		dat=p->data;
		l3.insert(dat);
		p=p->next;
	}
}}
int main()
{
	List<int>l1,l2,l3;
char ch;
int n;


	cout<<"Do you want to enter element in List 1 (y/n)"<<endl;
	cin>>ch;
	if(ch=='y')
	{
	l1.create();
}


cout<<"LIST 1"<<endl;
l1.display();

	cout<<"Do you want to enter element in List 2 (y/n)"<<endl;
	cin>>ch;
	if(ch=='y')
	{
	
	l2.create();
}

cout<<"LIST 2"<<endl;
l2.display();
do
{
	cout<<"Do you want to delete element in List 1 (y/n)"<<endl;
	cin>>ch;
	if(ch=='y')
	{
	l1.delete1();
}
}while(ch=='y');

do
{
	cout<<"Do you want to delete element in List 2 (y/n)"<<endl;
	cin>>ch;
	if(ch=='y')
	{
	l2.delete1();
}
}while(ch=='y');

l3.merge(l1,l2,l3);
cout<<"Merged List"<<endl;
l3.display();
return 0;
}
