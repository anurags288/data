#include<iostream.h>

template <class T>
class node
{ public : T info;
			  node *next;
			  node(T i, node *ptr=NULL)
			  { info=i;
				 next=ptr;
				 }
};

template <class T>
class list
{ node<T> *head, *tail;
  public: list()
			 { head=NULL;
				tail=NULL;
			  }
			  int isEmpty()
			  { if(head==NULL)
				  return 1;
				 return 0;
				}
			  ~list()
			  { while(head)
				 { node<T> *temp=head;
					head=head->next;
					delete temp;
					}
				}
			  void add(T);
			  void merge(list<T>);
			  T delNode();
			  void display();
};

template <class T>
void list<T> :: add(T x)
{ node<T> *temp=new node<T>(x);

  if(head==NULL)
	{ head=tail=temp; }
  else
  { tail->next=temp;
	 tail=temp;
	 }
}

template <class T>
T list<T> :: delNode()
{ if(isEmpty())
	{ cout<<endl<<"Empty list.";
	  return -1;
	  }
  else
  { node<T> *temp=head;
	 T t=tail->info;
	 for(;temp->next!=tail;temp=temp->next);
	 tail=temp;
	 if(head==tail)
	  head=NULL;
	 delete temp;
	 return t;
	}
}

template <class T>
void list<T> :: display()
{ node<T> *temp=head;
  while(temp)
	{ cout<<endl<<temp->info;
	  temp=temp->next;
	 }
}

//list merge(list l1,list l2);


template <class T>
void list<T> :: merge( list<T> l1)
{ node<T> *temp, *temp1, *temp2;
  list<T> l3;

  temp1=l1.head;
  temp2=head;
  //temp=l3->head;

  while(temp1 && temp2)
  { if(temp1->info < temp2->info)
	 { l3.add(temp1->info);
		temp1=temp1->next;
	  }
	 else
	 { l3.add(temp2->info);
		temp2=temp2->next;
	  }
	}

	while(temp1)
	{ l3.add(temp1->info);
	  temp1=temp1->next;
	  }

	while(temp2)
	{ l3.add(temp2->info);
	  temp2=temp2->next;
	 }

	l3.display();
}

int main()
{
  char ch,ch2,chn;

  do
 { cout<<endl<<"Enter the kind of list you want to create: ";
	cout<<endl<<"1. Character";
	cout<<endl<<"2. Integer";
	cout<<endl<<"3. Double";
	cout<<endl<<"Enter choice: ";

	int m;
	cin>>m;

  if(m==1)
  { list<char> l1, l2,l3;
  cout<<endl<<"Enter 1st ordered linked list: ";

  do
  { cout<<endl<<"Choose one of the following: ";
	 cout<<endl<<"1. Add element to tail.";
	 cout<<endl<<"2. Delete from tail.";
	 cout<<endl<<"3. Display the list.";

	 int choice;
	 cout<<endl<<"Enter choice: ";
	 cin>>choice;

	 char x;

	 switch(choice)
	 { case 1: cout<<endl<<"Enter the number you want to enter: ";
				  cin>>x;
				  l1.add(x);
				  break;
		case 2: x=l1.delNode();
				  if(x!=-1)
					cout<<endl<<x<<" is deleted.";
				  break;
		case 3: l1.display();
				  break;
		default: cout<<endl<<"Invalid choice.";
	  };

	  cout<<endl<<"Enter again? ";
	  cin>>ch;
	 } while(ch=='y' || ch=='Y');

	 cout<<endl<<"Enter the 2nd ordered list: ";

	do
  { cout<<endl<<"Choose one of the following: ";
	 cout<<endl<<"1. Add element to tail.";
	 cout<<endl<<"2. Delete from tail.";
	 cout<<endl<<"3. Display the list.";

	 int choice;
	 cout<<endl<<"Enter choice: ";
	 cin>>choice;

	 char x;

	 switch(choice)
	 { case 1: cout<<endl<<"Enter the number you want to enter: ";
				  cin>>x;
				  l2.add(x);
				  break;
		case 2: x=l2.delNode();
				  if(x!=-1)
					cout<<endl<<x<<" is deleted.";
				  break;
		case 3: l2.display();
				  break;
		default: cout<<endl<<"Invalid choice.";
	  };

	  cout<<endl<<"Enter again? ";
	  cin>>ch2;
	 } while(ch2=='y' || ch2=='Y');

	 cout<<endl<<"After merging the final list is: "<<endl;
	 l1.merge(l2);
	}
	else if(m==2)
	{ list<int> l1, l2,l3;
  cout<<endl<<"Enter 1st ordered linked list: ";

  do
  { cout<<endl<<"Choose one of the following: ";
	 cout<<endl<<"1. Add element to tail.";
	 cout<<endl<<"2. Delete from tail.";
	 cout<<endl<<"3. Display the list.";

	 int choice;
	 cout<<endl<<"Enter choice: ";
	 cin>>choice;

	 int x;

	 switch(choice)
	 { case 1: cout<<endl<<"Enter the number you want to enter: ";
				  cin>>x;
				  l1.add(x);
				  break;
		case 2: x=l1.delNode();
				  if(x!=-1)
					cout<<endl<<x<<" is deleted.";
				  break;
		case 3: l1.display();
				  break;
		default: cout<<endl<<"Invalid choice.";
	  };

	  cout<<endl<<"Enter again? ";
	  cin>>ch;
	 } while(ch=='y' || ch=='Y');

	 cout<<endl<<"Enter the 2nd ordered list: ";

	do
  { cout<<endl<<"Choose one of the following: ";
	 cout<<endl<<"1. Add element to tail.";
	 cout<<endl<<"2. Delete from tail.";
	 cout<<endl<<"3. Display the list.";

	 int choice;
	 cout<<endl<<"Enter choice: ";
	 cin>>choice;

	 int x;

	 switch(choice)
	 { case 1: cout<<endl<<"Enter the number you want to enter: ";
				  cin>>x;
				  l2.add(x);
				  break;
		case 2: x=l2.delNode();
				  if(x!=-1)
					cout<<endl<<x<<" is deleted.";
				  break;
		case 3: l2.display();
				  break;
		default: cout<<endl<<"Invalid choice.";
	  };

	  cout<<endl<<"Enter again? ";
	  cin>>ch2;
	 } while(ch2=='y' || ch2=='Y');

	 cout<<endl<<"After merging the final list is: "<<endl;
	 l1.merge(l2);
	}
	else if(m==3)
	{
	  list<double> l1, l2,l3;
  cout<<endl<<"Enter 1st ordered linked list: ";

  do
  { cout<<endl<<"Choose one of the following: ";
	 cout<<endl<<"1. Add element to tail.";
	 cout<<endl<<"2. Delete from tail.";
	 cout<<endl<<"3. Display the list.";

	 int choice;
	 cout<<endl<<"Enter choice: ";
	 cin>>choice;

	 double x;

	 switch(choice)
	 { case 1: cout<<endl<<"Enter the number you want to enter: ";
				  cin>>x;
				  l1.add(x);
				  break;
		case 2: x=l1.delNode();
				  if(x!=-1)
					cout<<endl<<x<<" is deleted.";
				  break;
		case 3: l1.display();
				  break;
		default: cout<<endl<<"Invalid choice.";
	  };

	  cout<<endl<<"Enter again? ";
	  cin>>ch;
	 } while(ch=='y' || ch=='Y');

	 cout<<endl<<"Enter the 2nd ordered list: ";

	do
  { cout<<endl<<"Choose one of the following: ";
	 cout<<endl<<"1. Add element to tail.";
	 cout<<endl<<"2. Delete from tail.";
	 cout<<endl<<"3. Display the list.";

	 int choice;
	 cout<<endl<<"Enter choice: ";
	 cin>>choice;

	 double x;

	 switch(choice)
	 { case 1: cout<<endl<<"Enter the number you want to enter: ";
				  cin>>x;
				  l2.add(x);
				  break;
		case 2: x=l2.delNode();
				  if(x!=-1)
					cout<<endl<<x<<" is deleted.";
				  break;
		case 3: l2.display();
				  break;
		default: cout<<endl<<"Invalid choice.";
	  };

	  cout<<endl<<"Enter again? ";
	  cin>>ch2;
	 } while(ch2=='y' || ch2=='Y');

	 cout<<endl<<"After merging the final list is: "<<endl;
	 l1.merge(l2);
	}
	cout<<endl<<"Create new list? ";
	cin>>chn;
	} while(chn=='y' || chn=='Y');
	cout<<endl<<"PROGRAM TERMINATING";


	 return 0;
}

